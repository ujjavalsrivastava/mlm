
const Footer = () => {
  
  return (
    <>
        <footer class="main-footer">
    <div class="pull-right hidden-xs">Version 1.2</div>
    Copyright © 2017 Yourdomian. All rights reserved.</footer>
     
    </>
  );
};

export default Footer;
