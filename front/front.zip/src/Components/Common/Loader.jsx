// src/components/Loader.js

import React from 'react';
import './Loader.css'; // Create appropriate CSS for loader

const Loader = () => {
  return (
   
      <div className="loader"></div>
   
  );
};

export default Loader;
