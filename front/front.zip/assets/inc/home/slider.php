<div class="page-title-home9">
            <div class="swiper-container slider-home9">
                <!-- Additional required wrapper -->
                <div class="swiper-wrapper">
                    <!-- Slides -->
                    <div class="swiper-slide" data-year="Start Your Career">
                        <div class="image">
                            <img src="images/dd-banner.jpg" alt="">
                        </div>
                        <div class="tf-container">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="content">
                                            <div>
                                                <div class="widget box-sub-tag fade-item fade-item-1 ">
                                                    <div class="sub-tag-icon">
                                                        <i class="icon-flash"></i>
                                                    </div>
                                                    <div class="sub-tag-title">
                                                        <p>We are Digital Duniyaa</p>
                                                    </div>
                                                </div>
                                                <h1 class="fade-item fade-item-1 fw-7 " style=" text-shadow: 0 2px black;">
                                                हुनर से शिखर तक
                                                 
                                                </h1>
                                                <div class="bottom-btns fade-item fade-item-1">
                                                    <a href="#" class="tf-btn style-secondary">View Our Programs<i
                                                            class="icon-arrow-top-right"></i></a>
                                                </div>
                                            </div>
                                            <!-- <div class="widget-video">
                                                <a href="https://www.youtube.com/watch?v=MLpWrANjFbI" class="popup-youtube">
                                                    <i class="flaticon-play fs-18"></i>
                                                </a>
                                                <h6 class="mb-0">Watch Demo</h6>
                                            </div> -->
                                        </div>                                    
                                        <div class="bot-wrap"></div>
                                    </div>
                                </div>
                        </div>
                    </div>


                </div>
                <!-- If we need pagination -->
                <div class="tf-container">
                    <div class="row">
                        <div class="col-12">
                            <div class="swiper-pagination"></div>
                        </div>
                    </div>
                </div>
                
            </div>
    

        </div>


 
                <!-- main-content -->
                <div class="main-content pt-0">       
